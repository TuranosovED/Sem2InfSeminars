#pragma once
void Task1();
void Task2();
void Task3();