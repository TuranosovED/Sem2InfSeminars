#pragma once
#define start_memory 50
void input(char* s);
void ClearBuffer();